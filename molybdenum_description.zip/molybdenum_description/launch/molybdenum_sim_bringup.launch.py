from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch_ros.actions import SetParameter, Node
from launch.launch_description_sources import PythonLaunchDescriptionSource
import xacro
import os

def generate_launch_description():
    ld = LaunchDescription()

    # Specify the name of the package and path to xacro file within the package
    pkg_name = 'molybdenum_description'
    file_subpath = 'urdf/molybdenum.urdf.xacro'
    config_subpath = 'config/twist_mux.yaml'

    #
    twist_mux_config_file = os.path.join(get_package_share_directory(pkg_name), config_subpath)
    # Use xacro to process the file - this gets published on the /robot_description topic
    xacro_file = os.path.join(get_package_share_directory(pkg_name), file_subpath)
    robot_description_raw = xacro.process_file(xacro_file).toxml()

    # Include the Gazebo launch file
    launch_gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([get_package_share_directory('coursework2'), '/launch', '/sim_bringup.launch.py']),
        launch_arguments={}.items(),
    )

    # robot state publisher node
    node_robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description_raw}]  # add other parameters here if required
    )

    node_spawn_entity = Node(package='ros_gz_sim', executable='create',
                             arguments=['-topic', '/robot_description',
                                        '-z', '0.5'],
                             output='screen')

    # Bridge
    # https://github.com/gazebosim/ros_gz/tree/humble/ros_gz_bridge
    node_ros_gz_bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=  [
                    '/clock' + '@rosgraph_msgs/msg/Clock'   + '[' + 'ignition.msgs.Clock',
                    '/model/molybdenum/cmd_vel'  +  '@geometry_msgs/msg/Twist'   + '@' + 'ignition.msgs.Twist',
                    '/model/molybdenum/odometry' +  '@nav_msgs/msg/Odometry'     + '[' + 'ignition.msgs.Odometry',
                    '/model/molybdenum/tf' +  '@tf2_msgs/msg/TFMessage' + '[' + 'ignition.msgs.Pose_V',
                    '/world/empty/model/molybdenum/joint_state' +  '@sensor_msgs/msg/JointState' + '[' + 'ignition.msgs.Model',
                    '/model/molybdenum/scan' +  '@sensor_msgs/msg/LaserScan' + '[' + 'ignition.msgs.LaserScan',
                    '/model/molybdenum/depth' + '@sensor_msgs/msg/Image' + '[' + 'ignition.msgs.Image',
                    '/model/molybdenum/imu' + '@sensor_msgs/msg/Imu' + '[' + 'ignition.msgs.IMU',
                    ],
        parameters= [{'qos_overrides./molybdenum.subscriber.reliability': 'reliable'}],
        remappings= [
                    ('/model/molybdenum/cmd_vel',  '/molybdenum/cmd_vel'),
                    ('/model/molybdenum/odometry','/odom_raw'),
                    ('/model/molybdenum/tf',  '/tf'),
                    ('/world/empty/model/molybdenum/joint_state','joint_states'),
                    ('/model/molybdenum/scan',  '/scan'),
                    ('/model/molybdenum/depth',  '/depth'),
                    ('/model/molybdenum/imu',  '/imu_raw'),
                    ],
        output='screen'
    )

    twist_mux = Node (  package='twist_mux',
                        executable='twist_mux',
                        name = 'twist_mux',
                        output='screen',
                        parameters=[twist_mux_config_file],
                        remappings={('/cmd_vel_out', '/molybdenum/cmd_vel')}
    )


    # Add actions to LaunchDescription
    ld.add_action(SetParameter(name='use_sim_time', value=False))
    ld.add_action(node_robot_state_publisher)
    ld.add_action(launch_gazebo)
    ld.add_action(node_spawn_entity)
    ld.add_action(twist_mux)
    ld.add_action(node_ros_gz_bridge)

    return ld